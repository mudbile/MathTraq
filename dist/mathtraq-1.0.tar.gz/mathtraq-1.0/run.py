from mathtraq.mathtraq import main
import sys

main(sys.argv)    